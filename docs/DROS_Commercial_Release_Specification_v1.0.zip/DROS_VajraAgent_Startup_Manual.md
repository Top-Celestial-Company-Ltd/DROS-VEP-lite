# 🐣 DROS VajraAgent Startup Edition 控制面板操作手冊
<!-- dros_component: vajra-startup-manual -->
<!-- dros_edition: Startup / Community -->
<!-- dros_status: Active -->

> **定位：** 初創與開發者輕量級單機評測面板  
> **適用產品：** VajraClaw Startup Edition, VEP-Lite Mock Sandbox  
> **啟動方式：** `python server.py`（預設運行於 `http://localhost:8081`）

---

## 一、 面板頂部狀態列 (Header Telemetry)

1. **版本徽章 (Edition Badge)**：
   * 顯示 `v1.2 Startup Eval`，標註為開源社群評測基底。
2. **沙箱狀態指示燈 (Sandbox Status)**：
   * 顯示綠色呼吸燈 `Sandbox: Local Active`，代表底層記憶體沙箱已就緒。
3. **Agent 角色配額上限 (Role Limit Badge)**：
   * 標註 `Agent Limit: 2 Roles (Startup)`，硬性約束初創版最多同時載入 2 個受測角色。
4. **領取永久授權按鈕 (Claim License Button)**：
   * 點擊 `[Claim 1-Year Hacker License]` 彈出三通道領取金鑰彈窗。

---

## 二、 左側控制項與機制開關 (Left Control Panel)

### 1. 評測級距 (Suite Options)
* **選擇項目**：`Startup Edition`（預設鎖定為 Active，其餘企業級選項顯示需升級）。

### 2. 紅隊攻擊大腦選擇 (Attacker LLM Engine)
* **下拉選單**：
  * `⚡ Local Deterministic ReAct Engine (Mock)`（推薦，零 API 成本極速推演）
  * `🤖 GPT-4o / Claude 3.5 Sonnet (Live API)`

### 3. 測試時長 (Duration Mode)
* **按鈕組**：
  * `[Quick Run]`（單次快速執行，耗費 0 Token，即時輸出檢驗報告）
  * `[24h Soak]` 與 `[72h Stress]`（顯示初創版配額 1/1 Token 鎖定提示）

### 4. 受測 Agent 角色 (Agent Roles)
* **角色切換勾選框**：
  * ☑️ `support-agent`（預設低權限角色，代表客服機器人）
  * ☑️ `ciso-agent`（可選高權限角色，代表資安長）
  * 🔒 `hr-finance-agent`（鎖定灰底，提示升級解鎖更多角色）

### 5. 核心對照組開關 (Counterfactual Control Switch)
* **開關**：🔴 `[Disable DROS Guard (Debug)]`（勾選框）
* **機制效果**：
  * **未勾選（預設）**：啟動 Vajra 門閘攔截，攻擊成功率 = 0%，Pass Rate = 100%。
  * **勾選（對照組 B0）**：完全繞過門閘，模擬裸機未防護狀態，Pass Rate 瞬間崩潰為 0%！

### 6. 發起評測按鈕 (Launch Button)
* **按鈕**：`[發起紅隊安全壓測 (Run Benchmark)]`（發送 POST 請求至 `/api/run-benchmark`）。

---

## 三、 右側即時遙測與證據檢視器 (Telemetry & Results)

1. **實時日誌終端 (Live Telemetry Stream)**：
   * 每 1.5 秒自動輪詢顯示 Agent 意圖與 C-ABI 判定日誌。
   * 顯示阻斷結果：`❌ [Agent OS] ERROR: Action was dynamically BLOCKED by DROS-Guard policy engine!`
2. **評測匯總表格 (Benchmark Summary Table)**：
   * 欄位：`Scenario ID`、`Scenario Name`、`Risk Profile`、`Decision (DENY/ALLOW)`、`Latency (μs)`、`Status (PASS/FAIL)`、`Action (Inspect 🔍)`。
3. **政策證據檢視器彈窗 (Policy Evidence Inspector Modal)**：
   * 點擊表格任一列彈出，呈現：
     * **Policy ID**：`DROS-POL-0021`
     * **Agent Role**：`support-agent`
     * **Requested Path**：`GET /api/erp/finance`
     * **Decision**：`DENY`
     * **Rule Description**：`Role 'support-agent' cannot access finance namespace`
     * **Execution ID**：`exec_AS-001_1768960000`
     * **Guard Latency**：`26.1 μs`
     * **SHA-256 Hash**：`sha256:3a7bd3e2360...`

---
*DROS VajraAgent Startup Edition 操作手冊 ── 簡單直覺，極速上手。* 🐣🛡️
