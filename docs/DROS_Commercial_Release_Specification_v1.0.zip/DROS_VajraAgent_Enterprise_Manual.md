# 🏢 DROS VajraAgent Enterprise Edition 控制面板操作手冊
<!-- dros_component: vajra-enterprise-manual -->
<!-- dros_edition: Enterprise Commercial -->
<!-- dros_status: Active -->

> **定位：** 企業生產級多 Agent 叢集、階梯式處置與長時間穩定性評測面板  
> **適用產品：** VajraClaw Enterprise, DROS Enterprise Gateway (Docker / K8s)  
> **啟動方式：** `python server.py`（預設運行於 `http://localhost:8082`）

---

## 一、 面板頂部狀態列 (Header Telemetry)

1. **版本與授權標章 (License Badge)**：
   * 顯示 `v2.0 Enterprise Commercial`，標註有效授權 `LIC-ENT-2026-0888`。
2. **叢集節點健康指示 (Cluster Health)**：
   * 顯示 `K8s DaemonSet: 3/3 Nodes Active` 綠色常亮燈。
3. **多 Agent 角色池 (Active Agent Pool)**：
   * 顯示 `Agent Swarm: 10 Roles Enabled (Unlimited)`，支援企業多部門全權限測試。
4. **階梯處置狀態 (Eviction Engine Status)**：
   * 標註 `Eviction Engine: Armed (Soft Deny / Quarantine / Hard Kill Active)`。

---

## 二、 左側控制項與機制開關 (Left Control Panel)

### 1. 評測級距 (Suite Options)
* **選擇項目**：`Enterprise Edition`（解鎖全棧 CRM、Gitea、Keycloak 與 ERP 模擬沙箱）。

### 2. 紅隊攻擊大腦 (Attacker LLM Engine)
* **下拉選單**：
  * 🔥 `GPT-5.6 Cyber (Adversarial Auto-Fuzzer)`（推薦，生成未知零日滲透 Payload）
  * ⚔️ `Fable 5 (Autonomous Jailbreak Agent)`
  * 🤖 `GPT-4o / Claude 3.5 Sonnet`

### 3. 測試時長與浸泡烘烤 (Duration & Soak Modes)
* **按鈕組**：
  * `[Quick Run]`（單次快速驗收）
  * `[24h Soak]`（執行 24 小時連續浸泡，驗證記憶體 0 洩漏與 RSS 穩定性）
  * `[72h Stress]`（執行 72 小時極限抗壓，160,000+ 次高頻調用）

### 4. 多部門 Agent 角色池 (Enterprise Swarm Roles)
* **支援多選與自訂勾選**：
  * ☑️ `support-agent` (客服)
  * ☑️ `accounting-agent` (會計)
  * ☑️ `ops-maintenance-agent` (運維)
  * ☑️ `hr-admin-agent` (人資)
  * ☑️ `ciso-agent` (資安總監)

### 5. 階梯式熔斷與處置開關 (Eviction Policy Controls)
* **開關組**：
  * ☑️ `Enable Soft Deny`（單次越權僅阻斷，回傳錯誤讓 Agent 自愈）
  * ☑️ `Enable Sliding Window Quarantine`（10 秒內違規滿 3 次自動降級唯讀沙箱）
  * ☑️ `Enable Physical Hard Kill`（偵測到 Direct Syscall / 日誌篡改時立即發送 SIGKILL）
  * 🔴 `[Bypass Guard (Control Group)]`（關閉全部防護作為科學對照組）

### 6. 一鍵匯出合規報告按鈕 (Export Compliance)
* **按鈕**：`[匯出歐盟 AI 法案 / NIST 合規報告 (Export Report)]`。

---

## 三、 右側即時遙測、審計鏈與取證面板 (Telemetry & Audit)

1. **階梯處置即時狀態監控 (Eviction Status Monitor)**：
   * 實時顯示處於 `Normal`、`Quarantined (隔離中)` 與 `Evicted (已處決)` 之 Agent 列表。
2. **Merkle 審計鏈實時流 (Cryptographic Audit Feed)**：
   * 顯示每筆交易之 `Sequence ID`、`Principal DID`、`Decision Latency (<30μs)` 與 `Parent Hash Continuity`。
3. **政策取證檢視器 (Enterprise Forensic Inspector)**：
   * 點擊任一事件，顯示完整交易參數、點陣圖匹配位元、觸發之處置級別與數位簽章清單。

---
*DROS VajraAgent Enterprise Edition 操作手冊 ── 企業級縱深防禦，穩健可靠。* 🏢🛡️
