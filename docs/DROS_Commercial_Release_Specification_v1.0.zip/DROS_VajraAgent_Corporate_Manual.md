# 🏛️ DROS VajraAgent Corporate Sovereign 控制面板操作手冊
<!-- dros_component: vajra-corporate-manual -->
<!-- dros_edition: Corporate / Sovereign Joint-Defense -->
<!-- dros_status: Active -->

> **定位：** 集團跨組織、B2B 供應鏈聯邦、主權防衛與硬實時邊緣旗艦面板  
> **適用產品：** VajraClaw Corporate, Sovereign Joint-Defense Network, PGM Microkernel  
> **啟動方式：** `python server.py`（預設運行於 `http://localhost:8083`）

---

## 一、 面板頂部狀態列 (Header Telemetry)

1. **主權信任根標章 (Sovereign Trust Anchor)**：
   * 顯示 `🔑 PKI CA: ROOT-2026 ACTIVE (ECDSA-P256 / Ed25519)` 綠色高亮燈。
2. **三層證書鏈驗證狀態 (3-Tier Cert Chain)**：
   * 標註 `DIT Token Verified · 3-Tier Cert Chain (Root CA ➔ Corp Org CA ➔ Agent DID)`。
3. **跨企業聯邦節點 (Federated Mesh Nodes)**：
   * 顯示 `B2B Mesh: 5 Enterprises Connected (Alpha Corp, Beta Repo, Gamma Gov...)`。
4. **亞微秒硬實時指標 (Hard Real-Time Latency)**：
   * 標註 `C-ABI Fast-Path: < 500 ns (Zero-Heap Bitmask Evaluation)`。

---

## 二、 左側控制項與機制開關 (Left Control Panel)

### 1. 評測級距 (Suite Options)
* **選擇項目**：`Sovereign Joint-Defense`（啟用跨企業 PKI 聯邦與邊緣無人載具硬實時防衛）。

### 2. 跨企業委託鏈約束 (Multi-Hop Delegation Constraints)
* **配置控制項**：
  * `Max Delegation Hops`：預設鎖定為 `2 Hops`（逐級強制遞減權限）。
  * `Token Epoch Window`：預設鎖定為 `60 Seconds`（亞微秒級 RCU 即時過期防重放）。

### 3. 紅隊攻擊大腦 (Sovereign Adversary Simulator)
* **下拉選單**：
  * 🔥 `Sovereign Nation-State Adversary Fuzzer (APT Matrix)`
  * ⚔️ `Cross-Enterprise Supply Chain Poisoning Engine (ATS-004)`
  * 🛸 `Swarm Mesh Hijack Simulator (DRONE-02)`

### 4. 實體具身智能與蜂群開關 (Physical AI Controls)
* **開關組**：
  * ☑️ `Mid-Air Disarm Lockout`（空中惡意停機指令 100% 物理硬阻絕）
  * ☑️ `Swarm Mesh 5-Hop Attenuation`（蜂群節點越權廣播熔斷）
  * ☑️ `Air-Gapped Cold-State Lockdown`（離線斷網環境密碼學身分校驗）

### 5. 全網緊急斷電電閘 (Global Sovereign Kill Switch)
* **按鈕**：🚨 `[EMERGENCY LOCKDOWN (全網 Fail-Closed 廣播熔斷)]`
* **機制效果**：一鍵向全聯邦節點廣播 CRL 撤銷清單，瞬間將所有未授權 Agent 權限歸零（$\Delta S \equiv 0$）！

---

## 三、 右側主權聯邦拓撲與法規大屏 (Sovereign Mesh & Legal Screen)

1. **跨企業 3D 拓撲動態圖 (B2B Federation Mesh Map)**：
   * 實時繪製 Corp-Alpha ➔ Corp-Beta 之委託調用射線與被攔截之毒化資料流。
2. **歐盟 AI 法案與美國 NIST 雙標準大屏 (Dual-Standard Compliance Board)**：
   * 實時統計並動態評分：
     * EU AI Act Article 50 (Traceability): `100% Compliant`
     * NIST SP 800-207 Zero Trust Invariant: `100% Verified`
3. **不可篡改 Merkle 司法級取證導出 (Court-Admissible Evidence Export)**：
   * 提供 `[下載 Ed25519 數位簽章取證包 (.tar.gz.sig)]`，包含完整父哈希連續性證明。

---
*DROS VajraAgent Corporate Sovereign 操作手冊 ── 最高主權防衛，堅不可摧。* 🏛️🛡️
